# Develop

[![CircleCI](https://circleci.com/gh/AnnelyseBe/MyBudget_repo3/tree/develop.svg?style=svg&circle-token=fc0e7ef03daa1a2fd8f57550fce49b7f1ccdd8d3)](https://circleci.com/gh/AnnelyseBe/MyBudget_repo3/tree/develop)

# Master
[![CircleCI](https://circleci.com/gh/AnnelyseBe/MyBudget_repo3/tree/master.svg?style=svg&circle-token=fc0e7ef03daa1a2fd8f57550fce49b7f1ccdd8d3)](https://circleci.com/gh/AnnelyseBe/MyBudget_repo3/tree/master)



# MyBudget_repo3
BudgetFile

# Requirements to program
* IntelliJ Lombok plugin
* Java11 SDK
* ....

# Techradar
* Spring Boot
* Mockito
* Spring data
* hibernate
* circleCI



# Documentation links
## Visual Datamodel
[Jhipster](https://start.jhipster.tech/jdl-studio/#!/view/63311fb0-1759-4c63-8335-8e8d95b74c04)

## Product backlog
[Trello] (https://trello.com/b/CWxfIdrm/budgetfile)

