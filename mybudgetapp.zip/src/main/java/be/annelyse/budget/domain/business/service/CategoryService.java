package be.annelyse.budget.domain.business.service;

import be.annelyse.budget.domain.business.model.Category;

public interface CategoryService extends CrudService<Category, Long> {


}
