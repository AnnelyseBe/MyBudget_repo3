package be.annelyse.budget.domain.business.service;

import be.annelyse.budget.domain.business.model.CostPost;

public interface CostPostService extends CrudService<CostPost, Long> {


}