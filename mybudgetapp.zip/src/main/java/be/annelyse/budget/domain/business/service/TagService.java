package be.annelyse.budget.domain.business.service;

import be.annelyse.budget.domain.business.model.Tag;

public interface TagService extends CrudService<Tag, Long> {


}
