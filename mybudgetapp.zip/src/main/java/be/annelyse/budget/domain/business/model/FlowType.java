package be.annelyse.budget.domain.business.model;

import java.io.Serializable;

public enum FlowType implements Serializable {
    EXPENSE, INCOME, BEGIN, TRANSFERT
}
